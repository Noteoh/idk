export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBdHBWP4QnufOernfS58Q6l6Ti4kXb9HlY",
    authDomain: "loginproject-835aa.firebaseapp.com",
    projectId: "loginproject-835aa",
    storageBucket: "loginproject-835aa.appspot.com",
    messagingSenderId: "643788678068",
    appId: "1:643788678068:web:f0930117ee1846f21808e1",
    measurementId: "G-WEVRVXX7MF",
    databaseURL : "https://loginproject-835aa-default-rtdb.europe-west1.firebasedatabase.app/"
  }
};
