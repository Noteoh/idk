# Quiz Angular App using OpenTDB API

This project was created by FOUAD Mohammed, TAMANT Reda, ELKHALIDY Youssef and ELFETHI Nouhaila

